export default function LeftStickyNav() {
  return (
    <div className="fixed left-0 top-0 bottom-0 z-50 hidden lg:flex w-[13%] min-w-[160px] max-w-[240px]">
      <div className="h-full w-full flex items-center justify-end border-r-[2px] border-stone-600/40 relative">
        <div className="flex flex-col items-end space-y-8 pr-8 text-right w-full">
          <a href="#home" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            Home
          </a>
          <a href="#projects" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            Projects
          </a>
          <a href="#about" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            About
          </a>
          <a href="#contact" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            Contact
          </a>
        </div>
      </div>
    </div>
  )
}