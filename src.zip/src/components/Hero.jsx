import { useEffect, useState } from 'react';

export default function Hero() {
  const [timeIST, setTimeIST] = useState('');

  useEffect(() => {
    const updateIST = () => {
      const now = new Date();
  
      // Convert to IST (UTC+5:30)
      const istOffset = 5.5 * 60; // in minutes
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const istTime = new Date(utc + istOffset * 60000);
  
      const hours = istTime.getHours().toString().padStart(2, '0');
      const minutes = istTime.getMinutes().toString().padStart(2, '0');
      const seconds = istTime.getSeconds().toString().padStart(2, '0');
  
      setTimeIST(`${hours}:${minutes}:${seconds}`);
    };
  
    updateIST();
    const interval = setInterval(updateIST, 1000);
  
    return () => clearInterval(interval);
  }, []);
  

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden text-white px-4 sm:px-6 md:pl-[160px] md:pr-[160px] lg:pl-[200px] lg:pr-[200px] xl:pl-[240px] xl:pr-[240px]">
      
      <div className="absolute top-0 left-0 w-full flex justify-between items-center px-4 sm:px-6 md:pl-[160px] md:pr-[160px] lg:pl-[200px] lg:pr-[200px] xl:pl-[150px] xl:pr-[150px] py-4 text-xs sm:text-sm tracking-widest z-10 border-b-[2px] border-stone-600/40">
        
        <div className="hidden lg:flex items-center gap-2 border border-white text-white px-3 py-1 rounded-full">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <p>Available For Work</p>
        </div>

        {/* Large screens: show time */}
        <p className="hidden lg:block text-stone-300">
          Local Time (IST):{' '}
          <span className="border border-white px-3 py-1 rounded-full text-white font-mono">
            {timeIST}
          </span>
        </p>

       {/* Small & Medium screens: show nav */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 flex gap-4 text-white text-xs sm:text-sm lg:hidden ">
          <a href="#home" className="hover:underline">Home</a>
          <a href="#services" className="hover:underline">Services</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </div>

      </div>

      {/* Center content */}
      <div className="px-6">
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="animate-bounce flex flex-col items-center">
          <span className="text-stone-400 text-xs mb-1">Scroll</span>
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            className="text-stone-400"
          >
            <path
              d="M7 13L12 18L17 13M7 6L12 11L17 6"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </section>
  );
}
