export default function RightStickyNav() {
  return (
    <div className="fixed right-0 top-0 bottom-0 z-50 hidden lg:flex w-[13%] min-w-[160px] max-w-[240px]">
      <div className="h-full w-full flex items-center border-l-[2px] border-stone-600/40 relative">
        <div className="flex flex-col items-start space-y-8 pl-8 w-full">
          <a href="mailto:you@example.com" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            Email
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            Twitter
          </a>
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            GitHub
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-stone-300 hover:text-white transition-colors text-sm uppercase tracking-widest">
            LinkedIn
          </a>
        </div>
      </div>
    </div>
  )
}