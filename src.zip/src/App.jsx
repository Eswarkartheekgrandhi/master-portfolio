import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import LeftStickyNav from './components/LeftStickyNav'
import RightStickyNav from './components/RightStickyNav'
import './App.css'
import Hero from './components/Hero'

function App() {

  return (
    <>
      <div className=" text-light min-h-screen">
        <LeftStickyNav />
        <Hero />
        <RightStickyNav />
      </div>
    </>
  )
}

export default App
